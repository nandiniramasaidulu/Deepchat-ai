export interface StreamSimulation {
  simulation?: boolean | number | string;
}

export type Stream = boolean | StreamSimulation;
