// https://docs.mistral.ai/api/#operation/createChatCompletion
export type Mistral = {
  model?: string;
  systemPrompt?: string;
};
