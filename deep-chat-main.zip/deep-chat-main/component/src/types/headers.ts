import {GenericObject} from './object';

export type BuildHeadersFunc = (key: string) => GenericObject<string>;
