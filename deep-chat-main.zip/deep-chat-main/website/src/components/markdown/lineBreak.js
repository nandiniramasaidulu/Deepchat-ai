import React from 'react';

export default function LineBreak() {
  return <div style={{height: '1px'}}></div>;
}
