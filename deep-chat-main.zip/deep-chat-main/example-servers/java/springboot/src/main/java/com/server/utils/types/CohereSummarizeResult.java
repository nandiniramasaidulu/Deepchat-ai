package com.server.utils.types;

public class CohereSummarizeResult {
  private String summary;
  private String message;

  public String getSummary() {
    return this.summary;
  }

  public String getMessage() {
    return this.message;
  }
}
