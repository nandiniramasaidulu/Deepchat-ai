package com.server.utils.types;

public class OpenAIChatResultMessage {
  private String content;

  public String getContent() {
    return this.content;
  }
}
