package com.server.utils.types;

public class OpenAIChatResultChoice {
  private OpenAIChatResultMessage message;

  public OpenAIChatResultMessage getMessage() {
    return this.message;
  }
}
